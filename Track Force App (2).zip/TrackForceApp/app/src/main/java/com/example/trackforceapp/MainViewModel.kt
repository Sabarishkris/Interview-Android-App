package com.example.trackforceapp


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.trackforceapp.model.Result
import com.example.trackforceapp.repository.Repository
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val repository = Repository()

    private val _listData = MutableLiveData<List<Result>>()
    val liveData: LiveData<List<Result>> get() = _listData


    private val _currentList = MutableLiveData<Result>()
    val currentPost: LiveData<Result> get() = _currentList

    init {
        viewModelScope.launch {
            try {
                val response = repository.getTopHeadlines()
                if (response.isSuccessful) {
                    val results = response.body()?.results ?: emptyList()
                    _listData.postValue(results)
                    if (results.isNotEmpty()) {

                        _currentList.postValue(results[0])
                    }
                } else {
                    _listData.postValue(emptyList())
                }
            } catch (e: Exception) {

                _listData.postValue(emptyList())
            }
        }
    }

    fun updatePost(post: Result) {
        _currentList.value = post
    }
}
