package com.example.trackforceapp


import android.content.res.Configuration

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.slidingpanelayout.widget.SlidingPaneLayout
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import androidx.window.layout.WindowLayoutInfo
import androidx.window.layout.WindowMetricsCalculator
import com.example.trackforceapp.databinding.ActivityMainBinding
import com.example.trackforceapp.util.getFeatureBoundsInWindow
import com.example.trackforceapp.util.isBookPosture
import com.example.trackforceapp.util.isFlatPostureHorizontal
import com.example.trackforceapp.util.isFlatPostureVertical
import com.example.trackforceapp.util.isTableTopPosture
import com.google.android.material.color.DynamicColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private lateinit var windowInfoTracker: WindowInfoTracker
    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        windowInfoTracker = WindowInfoTracker.getOrCreate(this@MainActivity)

        obtainWindowMetrics()

//        onWindowLayoutInfoChange()
        observeWindowLayoutInfo()

    }

    private fun obtainWindowMetrics() {
        Log.d("msg","obtain")
        val wmc = WindowMetricsCalculator.getOrCreate()
        val currentWM = wmc.computeCurrentWindowMetrics(this).bounds.flattenToString()
        val maximumWM = wmc.computeMaximumWindowMetrics(this).bounds.flattenToString()

        Log.d("msg","$currentWM")
        Log.d("msg","$maximumWM")
    }

//    private fun onWindowLayoutInfoChange() {
//        lifecycleScope.launch(Dispatchers.Main) {
//            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
//                Log.d("WindowInfo", "Lifecycle in STARTED state")
//                try {
//                    windowInfoTracker.windowLayoutInfo(this@MainActivity)
//                        .collect { value ->
//                            Log.d("WindowInfo", "WindowLayoutInfo collected: $value")
//                            updateUI(value)
//                        }
//                } catch (e: Exception) {
//                    Log.e("WindowInfo", "Error collecting WindowLayoutInfo", e)
//                }
//            }
//        }
//    }
    private fun observeWindowLayoutInfo() {
        lifecycleScope.launch(Dispatchers.Main) {
            try {
                windowInfoTracker.windowLayoutInfo(this@MainActivity)
                    .collect { value ->
                        Log.d("WindowInfo", "WindowLayoutInfo collected: $value")
                        updateUI(value)
                    }
            } catch (e: Exception) {
                Log.e("WindowInfo", "Error collecting WindowLayoutInfo", e)
            }
        }
    }



//    override fun onConfigurationChanged(newConfig: Configuration) {
//        super.onConfigurationChanged(newConfig)
//
//        when (newConfig.orientation) {
//            Configuration.ORIENTATION_LANDSCAPE -> {
//                Timber.d("onConfigurationChanged: Landscape")
//            }
//
//            Configuration.ORIENTATION_PORTRAIT -> {
//                Timber.d("onConfigurationChanged: Portrait")
//            }
//
//            else -> {
//                Timber.d("onConfigurationChanged: Other")
//            }
//        }
//    }

    private fun updateUI(newLayoutInfo: WindowLayoutInfo) {

        if (newLayoutInfo.displayFeatures.isNotEmpty()) {
            alignViewToFoldingFeatureBounds(newLayoutInfo)
            binding.slidingPaneLayout.lockMode = SlidingPaneLayout.LOCK_MODE_UNLOCKED
        } else {
            binding.slidingPaneLayout.closePane()
            binding.slidingPaneLayout.lockMode = SlidingPaneLayout.LOCK_MODE_LOCKED
        }
    }

    private fun alignViewToFoldingFeatureBounds(newLayoutInfo: WindowLayoutInfo) {
        val foldingFeature = newLayoutInfo.displayFeatures.filterIsInstance<FoldingFeature>()
            .firstOrNull() as FoldingFeature

        val bounds = getFeatureBoundsInWindow(foldingFeature, binding.root)

        bounds?.let { rect ->
            when {
                foldingFeature.isTableTopPosture() -> {
                    Timber.d("alignViewToFoldingFeatureBounds: TableTop Posture")
                    handleFoldOpen(newLayoutInfo)
                }

                foldingFeature.isBookPosture() -> {
                    Timber.d("alignViewToFoldingFeatureBounds: Book Posture")
                    handleFoldOpen(newLayoutInfo)
                }

                foldingFeature.isFlatPostureVertical() -> {
                    Log.d("msg","flatvertical")
                    handleFoldOpen(newLayoutInfo)

                }

                foldingFeature.isFlatPostureHorizontal() -> {
                    handleFoldOpen(newLayoutInfo)
                    Log.d("msg","flath")

                }

                else -> { // Unknown Posture
                    Timber.d("alignViewToFoldingFeatureBounds: Unknown Posture")
                }
            }
        }
    }
    private fun handleFoldOpen(windowLayoutInfo: WindowLayoutInfo) {
        val foldingFeature = windowLayoutInfo.displayFeatures
            .filterIsInstance<FoldingFeature>()
            .firstOrNull()

        foldingFeature?.let {
            when (it.state) {
                FoldingFeature.State.FLAT -> {
                    Log.d("msg", "flat")
                    binding.slidingPaneLayout.closePane()
                    binding.root.post {
                        // Ensure the layout is refreshed
                        binding.root.invalidate()
                    }
                }
                FoldingFeature.State.HALF_OPENED -> {
                    Log.d("msg", "half")
                    binding.slidingPaneLayout.openPane()
                    binding.root.post {
                        // Ensure the layout is refreshed
                        binding.root.invalidate()
                    }
                }
                else -> {
                    Log.d("msg", "close")
                    binding.slidingPaneLayout.closePane()
                    binding.root.post {
                        // Ensure the layout is refreshed
                        binding.root.invalidate()
                    }
                }
            }
        }
    }

}
