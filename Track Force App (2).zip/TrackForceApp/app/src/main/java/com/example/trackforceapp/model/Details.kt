package com.example.trackforceapp.model

data class Details(
    val info: Info,
    val results: List<Result>
)