package com.example.trackforceapp.ui.details

import android.annotation.SuppressLint

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.activityViewModels

import com.example.trackforceapp.MainActivity
import com.example.trackforceapp.MainViewModel
import com.example.trackforceapp.R
import com.example.trackforceapp.databinding.FragmentDetailsBinding
import com.example.trackforceapp.util.TwoPaneOnBackPressedCallback
import com.squareup.picasso.Picasso


@Suppress("DEPRECATION")
class DetailsFragment : Fragment() {
    private lateinit var mainActivity: MainActivity

    private val viewModel: MainViewModel by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        this.mainActivity = activity as MainActivity
        return inflater.inflate(R.layout.fragment_details, container, false)
    }

    @SuppressLint("SetTextI18n", "SuspiciousIndentation")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val binding = FragmentDetailsBinding.bind(view)

            binding.backPress.setOnClickListener {
                activity?.onBackPressed()
        }

        viewModel.currentPost.observe(this) {

            binding.apply {
                if (viewModel.currentPost.value?.picture?.medium != "null") {
                    Picasso.get().load(viewModel.currentPost.value?.picture?.medium).into(binding.employeeIcon)
                } else {
                   binding.employeeIcon.setImageResource(R.drawable.avatar)
                }
                binding.name.text =
                    viewModel.currentPost.value?.name?.first + " " + viewModel.currentPost.value?.name?.last
                binding.email.text = viewModel.currentPost.value?.email
                binding.number.text = viewModel.currentPost.value?.phone
                binding.employeeIdNo.text = viewModel.currentPost.value?.id?.name
                binding.idValue.text = viewModel.currentPost.value?.id?.value
                binding.gender.text = viewModel.currentPost.value?.gender
                binding.cell.text = viewModel.currentPost.value?.cell
            }
        }

        requireActivity().onBackPressedDispatcher.addCallback(
            viewLifecycleOwner,
            TwoPaneOnBackPressedCallback(mainActivity.binding.slidingPaneLayout)
        )
    }
}