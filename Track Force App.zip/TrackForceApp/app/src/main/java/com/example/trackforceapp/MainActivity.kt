package com.example.trackforceapp


import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.navigation.findNavController
import androidx.slidingpanelayout.widget.SlidingPaneLayout
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import androidx.window.layout.WindowLayoutInfo
import androidx.window.layout.WindowMetricsCalculator
import com.example.trackforceapp.databinding.ActivityMainBinding
import com.example.trackforceapp.util.getFeatureBoundsInWindow
import com.example.trackforceapp.util.isBookPosture
import com.example.trackforceapp.util.isFlatPostureHorizontal
import com.example.trackforceapp.util.isFlatPostureVertical
import com.example.trackforceapp.util.isTableTopPosture
import com.google.android.material.color.DynamicColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
 lateinit var viewModel: MainViewModel

    private lateinit var windowInfoTracker: WindowInfoTracker
    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        viewModel=ViewModelProvider(this)[MainViewModel::class.java]
        setContentView(binding.root)

        windowInfoTracker = WindowInfoTracker.getOrCreate(this@MainActivity)
//
//        obtainWindowMetrics()
//
////        onWindowLayoutInfoChange()
        observeWindowLayoutInfo()


    }

    private fun obtainWindowMetrics() {
        Log.d("msg", "obtain")
        val wmc = WindowMetricsCalculator.getOrCreate()
        val currentWM = wmc.computeCurrentWindowMetrics(this).bounds.flattenToString()
        val maximumWM = wmc.computeMaximumWindowMetrics(this).bounds.flattenToString()
        Log.d("msg", "$currentWM")
        Log.d("msg", "$maximumWM")
    }

    private fun observeWindowLayoutInfo() {
        lifecycleScope.launch(Dispatchers.Main) {
            windowInfoTracker.windowLayoutInfo(this@MainActivity)
                .collect { value ->
                    updateUI(value)
                }
        }
    }


    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        when (newConfig.orientation) {
            Configuration.ORIENTATION_LANDSCAPE -> {
                viewModel.orientationPo=false

                Timber.d("onConfigurationChanged: Landscape")
            }

            Configuration.ORIENTATION_PORTRAIT -> {
                viewModel.orientationPo=true
                Log.d("Msg","enter")
                Timber.d("onConfigurationChanged: Portrait")
            }

            else -> {
                Timber.d("onConfigurationChanged: Other")
            }
        }
    }

    private fun updateUI(newLayoutInfo: WindowLayoutInfo) {

        if (newLayoutInfo.displayFeatures.isNotEmpty()) {
            alignViewToFoldingFeatureBounds(newLayoutInfo)
//            binding.slidingPaneLayout.lockMode = SlidingPaneLayout.LOCK_MODE_UNLOCKED
        } else {
            binding.slidingPaneLayout.closePane()
            binding.slidingPaneLayout.lockMode = SlidingPaneLayout.LOCK_MODE_LOCKED
        }
    }

    private fun alignViewToFoldingFeatureBounds(newLayoutInfo: WindowLayoutInfo) {
        val foldingFeature = newLayoutInfo.displayFeatures.filterIsInstance<FoldingFeature>()
            .firstOrNull() as FoldingFeature

        val bounds = getFeatureBoundsInWindow(foldingFeature, binding.root)

        bounds?.let { react ->
            when {
                foldingFeature.isTableTopPosture() -> {
                    Log.d("msg", "toppost")

                }

                foldingFeature.isBookPosture() -> {
                    Log.d("msg", "post")
                    binding.slidingPaneLayout.visibility= View.VISIBLE
                    binding.detail.visibility=View.GONE
//                    handleFoldOpen(newLayoutInfo)
                }

                foldingFeature.isFlatPostureVertical() -> {
                    Log.d("msg", "flatvertical")
                    binding.slidingPaneLayout.visibility= View.GONE
                    binding.detail.visibility=View.VISIBLE
//                    findNavController(R.id.detailsFragment)

                }

                foldingFeature.isFlatPostureHorizontal() -> {
//                    handleFoldOpen(newLayoutInfo)
                    Log.d("msg", "flath")
                    binding.slidingPaneLayout.visibility= View.VISIBLE
                    binding.detail.visibility=View.GONE

                }

                else -> { // Unknown Posture
                    Log.d("msg", "else")
                }
            }
        }
    }


}
