package com.example.trackforceapp.model

data class Id(
    val name: String,
    val value: String
)