package com.example.trackforceapp.repository

import com.example.trackforceapp.api.ApiResponse
import com.example.trackforceapp.model.Details
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class Repository {
    private val BASE_URL = "https://randomuser.me/"

    val api: ApiResponse by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiResponse::class.java)
    }

    suspend fun getTopHeadlines(): Response<Details> {
        return api.getTopHeadlines()
    }
}