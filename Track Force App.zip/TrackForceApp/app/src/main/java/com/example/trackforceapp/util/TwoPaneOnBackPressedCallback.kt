package com.example.trackforceapp.util

import android.util.Log
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.slidingpanelayout.widget.SlidingPaneLayout

class TwoPaneOnBackPressedCallback(
    private val slidingPaneLayout: SlidingPaneLayout
) : OnBackPressedCallback(

    slidingPaneLayout.isSlideable && slidingPaneLayout.isOpen
),
    SlidingPaneLayout.PanelSlideListener {

    init {
        slidingPaneLayout.addPanelSlideListener(this)
    }

    override fun handleOnBackPressed() {
        Log.d("msg","back")
        slidingPaneLayout.closePane()
    }

    override fun onPanelSlide(panel: View, slideOffset: Float) {
        Log.d("msg","Slide")
        isEnabled=true
    }

    override fun onPanelOpened(panel: View) {
        Log.d("msg","open")
        isEnabled = true
    }

    override fun onPanelClosed(panel: View) {
        Log.d("msg","close")

        isEnabled = true
    }
}
