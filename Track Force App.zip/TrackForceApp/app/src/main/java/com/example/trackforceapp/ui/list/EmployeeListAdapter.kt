package com.example.trackforceapp.ui.list

import android.annotation.SuppressLint



import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.trackforceapp.R
import com.example.trackforceapp.model.Result
import com.example.trackforceapp.databinding.ListBinding
import com.squareup.picasso.Picasso

class EmployeeListAdapter(private val onItemClicked: (Result) -> Unit) :
    ListAdapter<Result, EmployeeListAdapter.ViewHolder>(DIFF_CALLBACK) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.itemView.setOnClickListener {
            onItemClicked(item)
        }
        holder.bind(item)
    }

    class ViewHolder(private val itemBinding: ListBinding) : RecyclerView.ViewHolder(itemBinding.root) {

        @SuppressLint("SetTextI18n")
        fun bind(item: Result) {

            itemBinding.employeeName.text = "${item.name.first} ${item.name.last}"

            if (item.picture.medium != "null") {
                Picasso.get().load(item.picture.medium).into(itemBinding.icon)
            } else {
                itemBinding.icon.setImageResource(R.drawable.avatar)
            }

        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Result>() {
            override fun areContentsTheSame(oldItem: Result, newItem: Result): Boolean {
                return oldItem == newItem
            }

            override fun areItemsTheSame(oldItem: Result, newItem: Result): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}
