package com.example.trackforceapp.model

data class Name(
    val first: String,
    val last: String,
    val title: String
)