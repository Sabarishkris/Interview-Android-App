package com.example.randomuserapp.module

data class Id(
    val name: String,
    val value: String
)