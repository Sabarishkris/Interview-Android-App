package com.example.randomuserapp.ui.listview

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import com.example.randomuserapp.module.Result
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.randomuserapp.R
import com.example.randomuserapp.databinding.FragmentListViewBinding
import com.example.randomuserapp.ui.list.ListViewViewModel
import com.squareup.picasso.Picasso

class ListViewFragment : Fragment() {
    private lateinit var binding: FragmentListViewBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_list_view, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val args = ListViewFragmentArgs.fromBundle(requireArguments())
        val picture=args.picture
        var name = args.name
        var  email= args.email
        val number= args.number
        val employeeIdNo = args.employeeIdNo
        val idValue= args.idValue
        val gender= args.gender
        val cell = args.cell

            binding.apply {
                if (picture.isNotEmpty() && picture != "null") {
                    Picasso.get().load(picture).into(employeeIcon)
                } else {
                    employeeIcon.setImageResource(R.drawable.avatar)
                }
                binding.name.text = name
                binding.email.text = email
                binding.number.text =number
                binding.employeeIdNo.text =employeeIdNo
                binding.idValue.text = idValue
                binding.gender.text = gender
                binding.cell.text = cell
            }
    }
}
