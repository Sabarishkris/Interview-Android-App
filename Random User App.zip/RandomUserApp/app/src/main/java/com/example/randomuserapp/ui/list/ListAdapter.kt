package com.example.randomuserapp.ui.list

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.randomuserapp.R
import com.example.randomuserapp.module.Result
import com.squareup.picasso.Picasso

class ListAdapter(private val list: List<Result>,private var setClick: SetClick) : RecyclerView.Adapter<ListAdapter.ViewHolder>() {

    class ViewHolder(view: View,setClick: SetClick) : RecyclerView.ViewHolder(view) {
        init {
            itemView.setOnClickListener {
                setClick.itemClicked(adapterPosition)
            }
        }
        val icon: ImageView = view.findViewById(R.id.icon)
        val name: TextView = view.findViewById(R.id.employee_name)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.list, parent, false)

        return ViewHolder(view,setClick)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val result = list[position]

        if (result.picture.medium != "null") {
            Picasso.get().load(result.picture.medium).into(holder.icon)
        } else {
            holder.icon.setImageResource(R.drawable.avatar)
        }
        holder.name.text = result.name.first+" "+result.name.last

    }


    override fun getItemCount(): Int {
        return list.size
    }
}
interface SetClick {
    fun itemClicked(position: Int)
}



