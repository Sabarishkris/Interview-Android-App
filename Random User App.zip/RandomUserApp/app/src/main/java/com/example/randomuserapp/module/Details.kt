package com.example.randomuserapp.module

data class Details(
    val info: Info,
    val results: List<Result>
)