package com.example.randomuserapp.api

import com.example.randomuserapp.module.Details
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiResponse {


                @GET("/api/?results=50&inc=gender,name,picture,phone,cell,id,email")
                suspend fun getTopHeadlines(): Response<Details>


}