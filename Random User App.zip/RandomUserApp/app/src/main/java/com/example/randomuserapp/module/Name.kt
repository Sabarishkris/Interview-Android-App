package com.example.randomuserapp.module

data class Name(
    val first: String,
    val last: String,
    val title: String
)