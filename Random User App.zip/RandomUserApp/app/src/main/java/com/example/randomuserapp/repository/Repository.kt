package com.example.randomuserapp.repository

import com.example.randomuserapp.api.ApiResponse
import com.example.randomuserapp.module.Details
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class Repository {
    private val BASE_URL = "https://randomuser.me/"

    val api: ApiResponse by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiResponse::class.java)
    }
//    private val retrofit = Retrofit.Builder()
//        .baseUrl("https://randomuser.me/api/")
//        .addConverterFactory(GsonConverterFactory.create())
//        .build()
//    private val apiService = retrofit.create(ApiResponse::class.java)
//
//    suspend fun getlist(): Response<Details> {
//        return apiService.getTopHeadlines()
//    }

    suspend fun getTopHeadlines(): Response<Details> {
        return api.getTopHeadlines()
    }
}