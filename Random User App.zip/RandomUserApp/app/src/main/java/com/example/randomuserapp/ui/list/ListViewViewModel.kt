package com.example.randomuserapp.ui.list

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.randomuserapp.R
import com.example.randomuserapp.module.Result
import com.example.randomuserapp.repository.Repository
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ListViewViewModel : ViewModel(),SetClick {
    @SuppressLint("StaticFieldLeak")
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ListAdapter
    private lateinit var repository: Repository


    private val _details = MutableLiveData<List<Result>>()
    val details: LiveData<List<Result>> get() = _details

    fun initialize(recyclerView: RecyclerView) {
        this.recyclerView = recyclerView
        this.repository = Repository()
        if(details.value==null) {
            fetchDetails()

        }
        setList()
    }

    private fun fetchDetails() {
        viewModelScope.launch {
            try {
                val response = repository.getTopHeadlines()
                if (response.isSuccessful) {
                    _details.postValue(response.body()?.results ?: emptyList())
                } else {
                    Log.e("UserViewModel", "Error fetching details: ${response.message()}")
                    _details.postValue(emptyList())
                }
            } catch (e: Exception) {
                Log.e("UserViewModel", "Exception fetching details", e)
                _details.postValue(emptyList())
            }
        }
    }
    fun setList(){
        Handler(Looper.getMainLooper()).post{
            _details.observeForever{
                result->
                    if(result!=null){
                        adapter=ListAdapter(result,this)
                        recyclerView.adapter=adapter
                    }else{
                        Log.e("Details Fetching adapter send", "No details to display")
                    }
                }
            }
    }

    override fun itemClicked(position: Int) {
        Log.d("position", position.toString())
        val detail = _details.value
        val selectedItem: Result? = detail?.get(position)
        val picture = selectedItem?.picture?.medium
        val name = "${selectedItem?.name?.first} ${selectedItem?.name?.last}"
        val email = selectedItem?.email
        val number = selectedItem?.phone
        val employeeIdNo = selectedItem?.id?.value
        val idValue = selectedItem?.id?.value
        val gender = selectedItem?.gender
        val cell = selectedItem?.cell

        val action = ListFragmentDirections.actionListFragmentToListViewFragment(picture = picture ?: "",
           name =  name, email =
            email ?: "", number =

            number ?: "", employeeIdNo =
            employeeIdNo ?: "", idValue =
            idValue ?: "", gender =
            gender ?: "", cell =
            cell ?: ""
        )

        // Navigate to ListViewFragment with the action
        recyclerView.findNavController().navigate(action)
    }



}