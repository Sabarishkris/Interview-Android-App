package com.example.employee360.datalayer.repository

import com.example.employee360.datalayer.local.CredentialDao
import com.example.employee360.datalayer.module.Credential
import kotlinx.coroutines.flow.Flow

class CredentialRepositoryImpl(private val dao: CredentialDao) : CredentialRepository {
    override suspend fun insert(credential: Credential) {
        dao.insert(credential)
    }

    override suspend fun deleteAllCredential() {
        dao.deleteAll()
    }

    override suspend fun getAllCredential(): Flow<List<Credential>> {
        return dao.getAllCredential()
    }
}