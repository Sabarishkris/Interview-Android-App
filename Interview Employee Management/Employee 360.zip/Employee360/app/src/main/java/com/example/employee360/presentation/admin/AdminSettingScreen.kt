package com.example.employee360.presentation.admin

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.presentation.employee.EmployeeHomeScreen


@Composable
fun AdminSettingScreen(navigate: NavHostController, modifier: Modifier) {

}