//package com.example.employee360.presentation.admin
//
//import android.net.Uri
//import android.widget.ImageView
//import androidx.compose.runtime.Composable
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.viewinterop.AndroidView
//import com.bumptech.glide.Glide
//
//@Composable
//fun GlideImage(imageUrl: String, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
////            ImageView(context).apply {
////                // Using Glide to load the image
////                Glide.with(context)
////                    .load(imageUrl)
////                    .into(this)
////            }
//        },
//        modifier = modifier
//    )
//}
//@Composable
//fun GlideImage(imageUri: Uri, modifier: Modifier = Modifier) {
//    AndroidView(
//        factory = { context ->
//            ImageView(context).apply {
//                scaleType = ImageView.ScaleType.CENTER_CROP
//            }
//        },
//        modifier = modifier,
//        update = { imageView ->
//            // Load image using Glide
//            Glide.with(imageView.context)
//                .load(imageUri)
//                .into(imageView)
//        }
//    )
//}