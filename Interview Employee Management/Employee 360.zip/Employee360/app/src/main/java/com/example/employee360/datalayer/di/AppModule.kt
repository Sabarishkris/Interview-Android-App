package com.example.employee360.datalayer.di

import android.app.Application
import androidx.room.Room
import com.example.employee360.datalayer.local.CredentialDataBase
import com.example.employee360.datalayer.local.EmployeeDataBase
import com.example.employee360.datalayer.repository.CredentialRepository
import com.example.employee360.datalayer.repository.CredentialRepositoryImpl
import com.example.employee360.datalayer.repository.EmployeeRepository
import com.example.employee360.datalayer.repository.EmployeeRepositoryImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideReportDatabase(app: Application): EmployeeDataBase {
        return Room.databaseBuilder(app, EmployeeDataBase::class.java, "employee").build()
    }

    @Provides
    @Singleton
    fun provideReportRepository(db:EmployeeDataBase):EmployeeRepository{
        return EmployeeRepositoryImpl(db.dao)
    }


    @Provides
    @Singleton
    fun provideCredentialDatabase(app: Application): CredentialDataBase {
        return Room.databaseBuilder(app, CredentialDataBase::class.java, "credential").build()
    }

    @Provides
    @Singleton
    fun provideCredentialRepository(db:CredentialDataBase):CredentialRepository{
        return CredentialRepositoryImpl(db.dao)
    }


}