package com.example.employee360.common

import androidx.compose.ui.graphics.vector.ImageVector

data class MiniFabItems(
    val icon: ImageVector,
    val title: String,
    val routes: String
)
