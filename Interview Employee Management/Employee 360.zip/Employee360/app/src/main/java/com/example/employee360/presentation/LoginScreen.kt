package com.example.employee360.presentation

import android.os.Build
import android.util.Log
import android.view.ViewTreeObserver
import android.widget.Toast
import androidx.annotation.RequiresExtension
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.example.employee360.R
import com.example.employee360.common.util.Routes
import com.example.employee360.domain.viewmodel.LoginViewModel

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun LoginScreen(navController: NavHostController, viewModel: LoginViewModel = hiltViewModel()) {
    val isImeVisible by rememberImeState()

    val credential by viewModel.credential.collectAsState(initial = emptyList());
    Log.d("msg", credential.toString())

    var userName by remember {
        mutableStateOf("")
    }
    var password by remember {
        mutableStateOf("")
    }
    val context = LocalContext.current
    LaunchedEffect(credential) {
        if (credential.isNotEmpty()) {

            val credentia = credential[0]

            when {
                viewModel.checkAdmin(credentia.email, credentia.password) -> {
                    navController.navigate(Routes.ADMIN_DASHBOARD_SCREEN)
                }

                viewModel.checkManager(credentia.email, credentia.password) -> {
                    val manager = viewModel.getTeamManager(credentia.email, credentia.password)
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        key = "manager",
                        value = manager
                    )
                    navController.navigate(Routes.MANAGER_DASHBOARD_SCREEN)
                }

                viewModel.checkEmployee(credentia.email, credentia.password) -> {
                    val data = viewModel.getEmployee(credentia.email, credentia.password);
                    navController.currentBackStackEntry?.savedStateHandle?.set(
                        key = "data",
                        value = data
                    )
                    navController.navigate(Routes.EMPLOYEE_DETAIL_SCREEN)
                }

                else -> {
                    Toast.makeText(context, "Invalid Credentials", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }
    GradientBox(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val animatedUpperSectionRatio by animateFloatAsState(
                targetValue = if (isImeVisible) 0f else 0.35f,
                label = "",
            )
            AnimatedVisibility(visible = !isImeVisible, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(animatedUpperSectionRatio),
                    contentAlignment = Alignment.Center
                ) {
                    Column (modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Text(
                            text = "Welcome to Employee 360",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onPrimary,
                        )
                        Image(
                            painter = painterResource(id = R.drawable.loginimag),
                            contentDescription = "Login Image",
                            modifier = Modifier.size(150.dp)
                        )
                    }

                }
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                    .background(MaterialTheme.colorScheme.surface),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Text(
                    text = "log in",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(16.dp)
                )

                MyTextField(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    label = "Email",

                    keyboardActions = KeyboardActions(),
                    value = userName,
                    onValueChange = { userName = it },
                )
                Spacer(modifier = Modifier.height(20.dp))
                MyTextField(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    label = "Password",

                    keyboardActions = KeyboardActions(),
                    trailingIcon = Icons.Default.Lock,
                    value = password,
                    onValueChange = { password = it },
                )

                if (isImeVisible) {
                    Button(
                        onClick = {
                            when {
                                viewModel.checkAdmin(userName, password) -> {
                                    viewModel.insertCredential("admin@email.com", "admin")
                                    navController.navigate(Routes.ADMIN_DASHBOARD_SCREEN)
                                }

                                viewModel.checkManager(userName, password) -> {
                                    viewModel.insertCredential(userName, password)
                                    val manager = viewModel.getTeamManager(userName, password)
                                    navController.currentBackStackEntry?.savedStateHandle?.set(
                                        key = "manager",
                                        value = manager
                                    )
                                    navController.navigate(Routes.MANAGER_DASHBOARD_SCREEN)
                                }

                                viewModel.checkEmployee(userName, password) -> {
                                    viewModel.insertCredential(userName, password)
                                    val data = viewModel.getEmployee(userName, password);
                                    navController.currentBackStackEntry?.savedStateHandle?.set(
                                        key = "data",
                                        value = data
                                    )
                                    navController.navigate(Routes.EMPLOYEE_DETAIL_SCREEN)
                                }

                                else -> {
                                    Toast.makeText(
                                        context,
                                        "Invalid Credentials",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 20.dp)
                            .padding(horizontal = 16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.surface
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "Log in",
                            style = TextStyle(fontSize = 18.sp, fontWeight = FontWeight(500))
                        )
                    }
                } else {

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp), contentAlignment = Alignment.CenterStart
                    ) {
                        Button(
                            onClick = {
                                when {
                                    viewModel.checkAdmin(userName, password) -> {
                                        viewModel.insertCredential("admin@email.com", "admin")
                                        navController.navigate(Routes.ADMIN_DASHBOARD_SCREEN)
                                    }

                                    viewModel.checkManager(userName, password) -> {
                                        viewModel.insertCredential(userName, password)
                                        val manager = viewModel.getTeamManager(userName, password)
                                        navController.currentBackStackEntry?.savedStateHandle?.set(
                                            key = "manager",
                                            value = manager
                                        )

                                        navController.navigate(Routes.MANAGER_DASHBOARD_SCREEN)
                                    }

                                    viewModel.checkEmployee(userName, password) -> {
                                        viewModel.insertCredential(userName, password)
                                        val data = viewModel.getEmployee(userName, password);
                                        navController.currentBackStackEntry?.savedStateHandle?.set(
                                            key = "data",
                                            value = data
                                        )
                                        navController.navigate(Routes.EMPLOYEE_DETAIL_SCREEN)
                                    }

                                    else -> {
                                        Toast.makeText(
                                            context,
                                            "Invalid Credentials",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "Log in",
                                style = TextStyle(
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight(500)
                                )
                            )
                        }
                    }
                }

            }
        }
    }
}


@Composable
fun GradientBox(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val secondaryColor = MaterialTheme.colorScheme.onPrimary
    Box(
        modifier = modifier.background(
            brush = Brush.linearGradient(
                listOf(
                    primaryColor, secondaryColor
                )
            )
        )
    ) {
        content()
    }
}


@Composable
fun MyTextField(
    modifier: Modifier = Modifier,
    label: String,
    keyboardActions: KeyboardActions,
    readOnly: Boolean = false,
    height: Dp = 42.dp,
    trailingIcon: ImageVector? = null,
    value: String,
    onValueChange: (String) -> Unit,

    ) {
    Column(modifier = modifier) {
        Text(text = label)
        Spacer(modifier = Modifier.height(10.dp))
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            keyboardActions = keyboardActions,
            readOnly = readOnly,
            keyboardOptions = KeyboardOptions(
                autoCorrectEnabled = false,
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Done
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .height(height)
                    .background(Color(0xFFEFEEEE)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    it.invoke()
                }
                trailingIcon?.let {
                    IconButton(onClick = { /*TODO*/ }) {
                        Icon(
                            imageVector = trailingIcon,
                            contentDescription = null,
                            tint = Color(0xFF828282)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun rememberImeState(): State<Boolean> {
    val imeState = remember {
        mutableStateOf(false)
    }
    val view = LocalView.current
    DisposableEffect(view) {
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            val isKeyboardOpen = ViewCompat.getRootWindowInsets(view)
                ?.isVisible(WindowInsetsCompat.Type.ime()) ?: true
            imeState.value = isKeyboardOpen
        }

        view.viewTreeObserver.addOnGlobalLayoutListener(listener)
        onDispose {
            view.viewTreeObserver.removeOnGlobalLayoutListener(listener)
        }
    }
    return imeState
}