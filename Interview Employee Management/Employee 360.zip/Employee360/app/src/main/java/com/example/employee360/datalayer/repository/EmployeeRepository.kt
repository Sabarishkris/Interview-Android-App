package com.example.employee360.datalayer.repository

import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import kotlinx.coroutines.flow.Flow

interface EmployeeRepository {

    suspend fun insert(employee: EmployeeDetails)

    suspend fun delete(employee: EmployeeDetails)

    //        suspend fun getNewsById(id:Int):EmployeeDetails?
    suspend fun getTeam(): Flow<List<Team>>

    fun getEmployees(): Flow<List<EmployeeDetails>>

    suspend fun deleteAllEmployee()

}