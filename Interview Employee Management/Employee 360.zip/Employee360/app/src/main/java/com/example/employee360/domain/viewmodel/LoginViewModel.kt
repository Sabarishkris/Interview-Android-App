package com.example.employee360.domain.viewmodel

import androidx.compose.runtime.collectAsState
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.employee360.datalayer.module.Credential
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.repository.CredentialRepository
import com.example.employee360.datalayer.repository.EmployeeRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val credentialRepository: CredentialRepository,
    private val employeeRepository: EmployeeRepository
) :
    ViewModel() {
    private val _credential = MutableStateFlow<List<Credential>>(emptyList())
    val credential: StateFlow<List<Credential>> = _credential


    private val _employee = MutableStateFlow<List<EmployeeDetails>>(emptyList())
    val employee: StateFlow<List<EmployeeDetails>> = _employee

    init {
        viewModelScope.launch {
            credentialRepository.getAllCredential().collect { credential ->
                _credential.value = credential
            }
        }
        viewModelScope.launch {
            employeeRepository.getEmployees().collect { employeeList ->
                _employee.value = employeeList
            }
        }
    }

    fun checkAdmin(userName: String, password: String): Boolean {
        if (userName.equals("admin@email.com") && password.equals("admin")) {
            return true;
        } else {
            return false;
        }
    }

    fun checkManager(userName: String, password: String): Boolean {
        val emp = employee.value
        return emp.any { it.email == userName && it.password == password && it.designation == "Manager" }
    }

    fun checkEmployee(userName: String, password: String): Boolean {
        val emp = employee.value
        return emp.any { it.email == userName && it.password == password }
    }

    fun getEmployee(email: String, password: String): EmployeeDetails? {
        var employe: EmployeeDetails? = null;
        employee.value.forEach { employee ->
            if (employee.email.equals(email) && employee.password.equals(password)) {
                employe = employee;
            }

        }
        return employe;
    }

    fun deleteAllCredential() {
        _credential.value= emptyList()
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                credentialRepository.deleteAllCredential()
//                    Log.d("msg", employee.toString())
            }
        }
    }

    fun insertCredential(email: String, password: String) {
        val credential = Credential(email = email, password = password)
        deleteAllCredential()
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
//                credentialRepository.getAllCredential()
                credentialRepository.insert(credential)
//                    Log.d("msg", employee.toString())
            }
        }
    }

    fun getTeamManager(email: String, password: String): EmployeeDetails? {
        var employe: EmployeeDetails? = null
        employee.value.forEach { employee ->
            if (employee.email.equals(email) && employee.password.equals(password) && employee.designation == "Manager") {
                employe = employee
            }

        }
        return employe
    }
}


