package com.example.employee360.datalayer.module

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Credential (
    @PrimaryKey
    val email:String,
    val password:String)