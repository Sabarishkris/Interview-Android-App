package com.example.employee360.common.util

sealed class UiState {

        object Success : UiState()
        object Error : UiState()
        object Loading : UiState()

}