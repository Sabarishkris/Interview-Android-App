package com.example.employee360.datalayer.repository

import com.example.employee360.datalayer.local.EmployeeDao
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import kotlinx.coroutines.flow.Flow

class EmployeeRepositoryImpl(private val dao: EmployeeDao) : EmployeeRepository {

    override suspend fun insert(employee: EmployeeDetails) {
        dao.insert(employee)
    }

    override suspend fun delete(employee: EmployeeDetails) {
        dao.delete(employee)
    }

    override suspend fun getTeam(): Flow<List<Team>> {
        return dao.getTeam()
    }


    override fun getEmployees(): Flow<List<EmployeeDetails>> {
        return dao.getReports()
    }

    override suspend fun deleteAllEmployee() {
        return dao.deleteall()
    }
}