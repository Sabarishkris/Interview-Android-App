package com.example.employee360.datalayer.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.employee360.datalayer.module.Credential
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.newsappjetpack.datalayer.converters.Converters

@Database(entities = [Credential::class], version = 1, exportSchema = false)
abstract class CredentialDataBase:RoomDatabase() {
    abstract val dao:CredentialDao
}