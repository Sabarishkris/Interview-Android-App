package com.example.employee360.datalayer.module

import android.graphics.Bitmap
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity
data class EmployeeDetails(
    @ColumnInfo(name = "id")
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val name: String,
    val designation: String,
    val team: String,
    val salary: String,
    val profileImageUrl: Bitmap,
    val password:String,
    val email:String
): Parcelable