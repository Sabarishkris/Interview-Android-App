package com.example.employee360.presentation

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresExtension
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.employee360.common.util.Routes
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.presentation.admin.AddEmployeeScreen
import com.example.employee360.presentation.admin.AddTeamScreen

import com.example.employee360.presentation.admin.AdminMainScreen
import com.example.employee360.presentation.employee.EmployeeDetails
import com.example.employee360.presentation.employee.EmployeeMainScreen
import com.example.employee360.presentation.manager.ManagerMainScreen


@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun MyNavigation() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.LOGIN_SCREEN) {

        composable(route = Routes.LOGIN_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            LoginScreen(navController)
        }
        composable(route = Routes.ADMIN_DASHBOARD_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            AdminMainScreen(navigate = navController)
        }
        composable(route = Routes.ADD_TEAM_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            AddTeamScreen(navController)
        }
        composable(route = Routes.ADD_EMPLOYEE_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            AddEmployeeScreen(navController)

        }
        composable(route = Routes.MANAGER_DASHBOARD_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) { backStackEntry ->
            val manager: EmployeeDetails? =
                navController.previousBackStackEntry?.savedStateHandle?.get<EmployeeDetails>("manager")
            if (manager != null) {
                Log.d("graph manager",manager.toString())
                ManagerMainScreen(navigate = navController, manager)
            }
        }

        composable(route = Routes.EMPLOYEE_DETAIL_SCREEN,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            val employee: EmployeeDetails? =
                navController.previousBackStackEntry?.savedStateHandle?.get<EmployeeDetails>("data")
            if (employee != null) {
                EmployeeMainScreen(navController,employeeDetails = employee)
            }
        }
        composable(route = Routes.EMPLOYEE_VIEW,
            enterTransition = {
                scaleIntoContainer()
            },
            exitTransition = {
                scaleOutOfContainer(direction = ScaleTransitionDirection.INWARDS)
            },
            popEnterTransition = {
                scaleIntoContainer(direction = ScaleTransitionDirection.OUTWARDS)
            },
            popExitTransition = {
                scaleOutOfContainer()
            }
        ) {
            val employee: EmployeeDetails? =
                navController.previousBackStackEntry?.savedStateHandle?.get<EmployeeDetails>("data")
            if (employee != null) {
                EmployeeDetails(navController,employeeDetails = employee)
            }
        }
    }
}


fun scaleIntoContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.INWARDS,
    initialScale: Float = if (direction == ScaleTransitionDirection.OUTWARDS) 0.9f else 1.1f
): EnterTransition {
    return scaleIn(
        animationSpec = tween(220, delayMillis = 90),
        initialScale = initialScale
    ) + fadeIn(animationSpec = tween(220, delayMillis = 90))
}

fun scaleOutOfContainer(
    direction: ScaleTransitionDirection = ScaleTransitionDirection.OUTWARDS,
    targetScale: Float = if (direction == ScaleTransitionDirection.INWARDS) 0.9f else 1.1f
): ExitTransition {
    return scaleOut(
        animationSpec = tween(
            durationMillis = 220,
            delayMillis = 90
        ), targetScale = targetScale
    ) + fadeOut(tween(delayMillis = 90))
}

enum class ScaleTransitionDirection {
    INWARDS,
    OUTWARDS
}