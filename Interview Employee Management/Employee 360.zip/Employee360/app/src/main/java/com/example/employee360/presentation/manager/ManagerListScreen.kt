package com.example.employee360.presentation.manager

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import com.example.employee360.presentation.AnimatedShimmer
import com.example.employee360.presentation.admin.EmployeeListItem
import com.example.employee360.presentation.admin.SearchBar
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun ManagerListScreen(navigate: NavHostController, employees: List<EmployeeDetails>, modifier: Modifier ) {

    var searchQuery by remember { mutableStateOf("") }


    var selectedTeam by remember { mutableStateOf<Team?>(null) }


    val filteredEmployees = employees.filter { employee ->

        (employee.name.contains(searchQuery, ignoreCase = true) || employee.designation.contains(
            searchQuery,
            ignoreCase = true
        )) &&
                (selectedTeam == null || employee.team == selectedTeam?.team)
    }
    val scope = rememberCoroutineScope()
    var loading by remember {
        mutableStateOf(true)
    }
    scope.launch {
        delay(1000L)
        loading = false
    }
    Column(
        modifier = modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {

        SearchBar(
            query = searchQuery,
            onQueryChanged = { searchQuery = it }
        )
        if (loading) {
            repeat(7) {
                AnimatedShimmer()
            }
        } else {
            filteredEmployees.forEach { employee ->
                EmployeeListItem(employee, navigate)

            }
        }
    }

    }