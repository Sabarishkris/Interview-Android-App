package com.example.employee360.common

import androidx.compose.ui.graphics.vector.ImageVector

data class DrawerItems(
    val icon : ImageVector,
    val Name : String,
)