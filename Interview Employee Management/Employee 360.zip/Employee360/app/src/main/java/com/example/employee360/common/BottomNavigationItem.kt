package com.example.employee360.common

import androidx.compose.ui.graphics.vector.ImageVector

data class BottomNavigationItem(
    val title:String,
    val route:String,
    val icon:ImageVector
)