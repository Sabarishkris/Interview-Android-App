package com.example.employee360.presentation.admin

import android.annotation.SuppressLint
import android.os.Build
import androidx.annotation.RequiresExtension
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.scrollable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column


import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.motionEventSpy
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.employee360.common.util.UiState
import com.example.employee360.datalayer.module.EmployeeDetails
import com.example.employee360.datalayer.module.Team
import com.example.employee360.domain.viewmodel.AdminViewModel
import com.example.employee360.presentation.AnimatedShimmer
import com.example.employee360.presentation.employee.EmployeeHomeScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.time.Duration.Companion.seconds

@SuppressLint("CoroutineCreationDuringComposition")
@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@Composable
fun AdminDashboardScreen(
    viewModel: AdminViewModel,
    navigate: NavHostController,
    employees: List<EmployeeDetails>,
    teams: List<Team>,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    var loading by remember {
        mutableStateOf(true)
    }
    scope.launch {
        delay(1000L)
        loading = false
    }
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(start = 16.dp, end = 16.dp)
            .verticalScroll(scrollState)
    ) {
        if (loading) {
            repeat(7) {
                AnimatedShimmer()
            }
        } else {

            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                CategoryItem(
                    employees.size,
                    "Total Employee",
                    modifier = Modifier.wrapContentSize()
                )
                CategoryItem(
                    teams.size,
                    "Total Team",
                    modifier = Modifier.wrapContentSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(text = "Recent Employees", style = MaterialTheme.typography.titleMedium)


            employees.takeLast(5).forEachIndexed { index, employee ->
                EmployeeListItem(employee, navigate)
            }

            Spacer(modifier = Modifier.height(16.dp))
//            Divider(modifier = Modifier
//                .fillMaxWidth()
//                .padding(10.dp))

            Text(text = "Chart ", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(16.dp))
            EmployeeCountGraph(teams = teams)
            Spacer(modifier = Modifier.height(30.dp))
        }
    }


}

@Composable
fun CategoryItem(count: Int, msg: String, modifier: Modifier ) {

    Card(
        colors = CardDefaults.cardColors(
            MaterialTheme.colorScheme.secondaryContainer
        ),
        modifier = modifier
            .padding(5.dp)
            .wrapContentSize()
    ) {
        Column(
            modifier = modifier,
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = msg,
                fontSize = MaterialTheme.typography.titleMedium.fontSize,
                fontWeight = FontWeight.Thin,
                modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.CenterHorizontally),
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$count",
                fontSize = MaterialTheme.typography.titleLarge.fontSize,
                fontWeight = MaterialTheme.typography.titleLarge.fontWeight,
                modifier = Modifier
                    .padding(5.dp)
                    .align(Alignment.CenterHorizontally),
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwipeTODismissItem(
    item: EmployeeDetails,
    onRemove: () -> Unit,
    modifier: Modifier,
    navigate: NavHostController,
    viewModel: AdminViewModel
) {
    val coroutineScope = rememberCoroutineScope()


    val swipeToDismissBoxState = rememberSwipeToDismissBoxState(
        confirmValueChange = { state ->
            if (state == SwipeToDismissBoxValue.EndToStart) {
                coroutineScope.launch {
                    delay(300)
                    onRemove()
                }
                true
            } else {
                false
            }
        }
    )

    SwipeToDismissBox(
        state = swipeToDismissBoxState,
        backgroundContent = {
            val backgroundColor by animateColorAsState(
                targetValue = when (swipeToDismissBoxState.currentValue) {
                    SwipeToDismissBoxValue.StartToEnd -> Color.Green
                    SwipeToDismissBoxValue.EndToStart -> Color.Red
                    SwipeToDismissBoxValue.Settled -> MaterialTheme.colorScheme.surface
                }
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(backgroundColor)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "delete",
                    tint = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        modifier = Modifier
    ) {
        EmployeeListItem(item, navigate)
    }
}