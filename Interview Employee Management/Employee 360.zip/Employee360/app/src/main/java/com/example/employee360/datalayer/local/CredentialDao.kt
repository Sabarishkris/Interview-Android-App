package com.example.employee360.datalayer.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.employee360.datalayer.module.Credential
import com.example.employee360.datalayer.module.EmployeeDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface CredentialDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(credential: Credential)

    @Query("select * from credential")
    fun getAllCredential(): Flow<List<Credential>>

    @Query("delete from credential")
    fun deleteAll()
}